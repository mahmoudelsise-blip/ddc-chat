package com.ddc.chat

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Timestamp
import java.util.concurrent.TimeUnit
import java.text.SimpleDateFormat
import java.util.Locale

private val DdcGreen = Color(0xFF00D879)
private val DdcBackground = Color(0xFF07110E)
private val DdcSurface = Color(0xFF111D18)
private val DdcSent = Color(0xFF07543D)
private val DdcReceived = Color(0xFF1A2922)
private val DdcMuted = Color(0xFF9BAAA2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val firebaseConfigured = FirebaseApp.initializeApp(this) != null
        setContent {
            val colors = darkColorScheme(
                primary = DdcGreen,
                onPrimary = Color(0xFF002313),
                background = DdcBackground,
                onBackground = Color.White,
                surface = DdcSurface,
                onSurface = Color.White,
                secondary = DdcGreen
            )
            MaterialTheme(colorScheme = colors) {
                Surface(modifier = Modifier.fillMaxSize(), color = DdcBackground) {
                    androidx.compose.runtime.CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        DdcApp(firebaseConfigured = firebaseConfigured)
                    }
                }
            }
        }
    }
}

private enum class AppPage { PHONE, OTP, PROFILE, HOME, CHAT }

private data class DdcProfile(
    val uid: String,
    val displayName: String,
    val username: String
)

private data class DdcChat(
    val id: String,
    val members: List<String>,
    val memberNames: Map<String, String>,
    val lastMessage: String
) {
    fun otherUid(currentUid: String): String = members.firstOrNull { it != currentUid }.orEmpty()
}

private data class DdcMessage(
    val id: String,
    val senderId: String,
    val text: String,
    val createdAt: Timestamp?
)

@Composable
private fun DdcApp(firebaseConfigured: Boolean) {
    val context = LocalContext.current
    val auth = remember(firebaseConfigured) { if (firebaseConfigured) FirebaseAuth.getInstance() else null }
    val db = remember(firebaseConfigured) { if (firebaseConfigured) FirebaseFirestore.getInstance() else null }

    var page by remember { mutableStateOf(AppPage.PHONE) }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var profile by remember { mutableStateOf<DdcProfile?>(null) }
    var activeUid by remember { mutableStateOf<String?>(null) }
    var activeChat by remember { mutableStateOf<DdcChat?>(null) }
    var notice by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun finishSignIn(user: FirebaseUser) {
        activeUid = user.uid
        busy = true
        db?.collection("profiles")?.document(user.uid)?.get()
            ?.addOnSuccessListener { snapshot ->
                busy = false
                if (snapshot.exists()) {
                    profile = DdcProfile(
                        uid = user.uid,
                        displayName = snapshot.getString("displayName").orEmpty(),
                        username = snapshot.getString("username").orEmpty()
                    )
                    page = AppPage.HOME
                } else {
                    page = AppPage.PROFILE
                }
            }
            ?.addOnFailureListener { error ->
                busy = false
                notice = "تعذر تحميل الحساب: ${error.localizedMessage ?: "حاول مرة أخرى"}"
            }
    }

    LaunchedEffect(firebaseConfigured) {
        auth?.currentUser?.let { finishSignIn(it) }
    }

    fun startChatByUsername(rawUsername: String) {
        val myProfile = profile ?: return
        val store = db ?: return
        val username = rawUsername.trim().removePrefix("@").lowercase()
        if (!Regex("^[a-z0-9_]{3,20}$").matches(username)) {
            notice = "اسم المستخدم يجب أن يكون من 3 إلى 20 حرفًا إنجليزيًا أو رقمًا أو _"
            return
        }
        if (username == myProfile.username) {
            notice = "لا يمكنك بدء محادثة مع نفسك"
            return
        }
        busy = true
        store.collection("usernames").document(username).get()
            .addOnSuccessListener { userNameDoc ->
                val otherUid = userNameDoc.getString("uid")
                if (otherUid.isNullOrBlank()) {
                    busy = false
                    notice = "اسم المستخدم غير موجود"
                    return@addOnSuccessListener
                }
                store.collection("profiles").document(otherUid).get()
                    .addOnSuccessListener { otherDoc ->
                        if (!otherDoc.exists()) {
                            busy = false
                            notice = "الحساب غير متاح حاليًا"
                            return@addOnSuccessListener
                        }
                        val otherName = otherDoc.getString("displayName").orEmpty().ifBlank { username }
                        val members = listOf(myProfile.uid, otherUid).sorted()
                        val chatId = members.joinToString("_")
                        val chatRef = store.collection("chats").document(chatId)
                        chatRef.get().addOnSuccessListener { existing ->
                            if (existing.exists()) {
                                activeChat = chatFromSnapshot(chatId, existing.data.orEmpty())
                                page = AppPage.CHAT
                                busy = false
                            } else {
                                val names = mapOf(myProfile.uid to myProfile.displayName, otherUid to otherName)
                                val newChat = mapOf(
                                    "members" to members,
                                    "memberNames" to names,
                                    "lastMessage" to "",
                                    "createdAt" to FieldValue.serverTimestamp(),
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                                chatRef.set(newChat)
                                    .addOnSuccessListener {
                                        activeChat = DdcChat(chatId, members, names, "")
                                        page = AppPage.CHAT
                                        busy = false
                                    }
                                    .addOnFailureListener { error ->
                                        busy = false
                                        notice = "تعذر إنشاء المحادثة: ${error.localizedMessage ?: "خطأ غير معروف"}"
                                    }
                            }
                        }.addOnFailureListener { error ->
                            busy = false
                            notice = "تعذر فتح المحادثة: ${error.localizedMessage ?: "حاول مرة أخرى"}"
                        }
                    }
                    .addOnFailureListener { error ->
                        busy = false
                        notice = "تعذر العثور على الحساب: ${error.localizedMessage ?: "حاول مرة أخرى"}"
                    }
            }
            .addOnFailureListener { error ->
                busy = false
                notice = "تعذر البحث: ${error.localizedMessage ?: "حاول مرة أخرى"}"
            }
    }

    when (page) {
        AppPage.PHONE -> PhonePage(
            phone = phone,
            onPhoneChange = { phone = it },
            firebaseConfigured = firebaseConfigured,
            busy = busy,
            notice = notice,
            onSendCode = {
                notice = ""
                val normalized = normalizePhone(phone)
                val activity = context as? Activity
                if (!firebaseConfigured || auth == null || activity == null) {
                    notice = "اربط Firebase أولًا بإضافة الملف app/google-services.json"
                } else if (normalized.length < 9 || !normalized.startsWith("+")) {
                    notice = "اكتب رقم الهاتف بكود الدولة، مثال: +201012345678"
                } else {
                    busy = true
                    val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                            auth.signInWithCredential(credential).addOnCompleteListener { task ->
                                busy = false
                                if (task.isSuccessful) task.result?.user?.let { finishSignIn(it) }
                                else notice = task.exception?.localizedMessage ?: "تعذر تسجيل الدخول"
                            }
                        }

                        override fun onVerificationFailed(error: Exception) {
                            busy = false
                            notice = error.localizedMessage ?: "فشل إرسال رمز التحقق"
                        }

                        override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                            busy = false
                            verificationId = id
                            page = AppPage.OTP
                        }
                    }
                    val options = PhoneAuthOptions.newBuilder(auth)
                        .setPhoneNumber(normalized)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(activity)
                        .setCallbacks(callbacks)
                        .build()
                    PhoneAuthProvider.verifyPhoneNumber(options)
                }
            }
        )

        AppPage.OTP -> OtpPage(
            otp = otp,
            onOtpChange = { otp = it },
            busy = busy,
            notice = notice,
            onVerify = {
                val id = verificationId
                if (id.isNullOrBlank() || otp.trim().length < 6 || auth == null) {
                    notice = "اكتب رمز التحقق المكوّن من 6 أرقام"
                } else {
                    busy = true
                    val credential = PhoneAuthProvider.getCredential(id, otp.trim())
                    auth.signInWithCredential(credential).addOnCompleteListener { task ->
                        busy = false
                        if (task.isSuccessful) task.result?.user?.let { finishSignIn(it) }
                        else notice = task.exception?.localizedMessage ?: "رمز التحقق غير صحيح"
                    }
                }
            },
            onBack = { page = AppPage.PHONE; notice = "" }
        )

        AppPage.PROFILE -> ProfilePage(
            busy = busy,
            notice = notice,
            onSave = { displayName, usernameInput ->
                val uid = activeUid
                val store = db
                val username = usernameInput.trim().removePrefix("@").lowercase()
                if (uid == null || store == null) {
                    notice = "سجّل الدخول أولًا"
                } else if (displayName.trim().length < 2) {
                    notice = "اكتب اسمًا من حرفين على الأقل"
                } else if (!Regex("^[a-z0-9_]{3,20}$").matches(username)) {
                    notice = "اسم المستخدم من 3 إلى 20 حرفًا إنجليزيًا أو رقمًا أو _"
                } else {
                    busy = true
                    val usernameRef = store.collection("usernames").document(username)
                    store.runTransaction { transaction ->
                        val existing = transaction.get(usernameRef)
                        if (existing.exists()) throw IllegalStateException("اسم المستخدم مستخدم بالفعل")
                        transaction.set(usernameRef, mapOf("uid" to uid))
                        transaction.set(
                            store.collection("profiles").document(uid),
                            mapOf(
                                "displayName" to displayName.trim(),
                                "username" to username,
                                "createdAt" to FieldValue.serverTimestamp()
                            ),
                            SetOptions.merge()
                        )
                    }.addOnSuccessListener {
                        busy = false
                        profile = DdcProfile(uid, displayName.trim(), username)
                        page = AppPage.HOME
                        notice = ""
                    }.addOnFailureListener { error ->
                        busy = false
                        notice = error.localizedMessage ?: "تعذر حفظ الملف الشخصي"
                    }
                }
            }
        )

        AppPage.HOME -> {
            val uid = activeUid
            val userProfile = profile
            val store = db
            if (uid == null || userProfile == null || store == null) {
                PhonePage(phone, { phone = it }, firebaseConfigured, busy, "حدث خطأ في الحساب. سجّل الدخول مجددًا.", { page = AppPage.PHONE })
            } else {
                DdcHome(
                    db = store,
                    uid = uid,
                    profile = userProfile,
                    notice = notice,
                    busy = busy,
                    onStartChat = { startChatByUsername(it) },
                    onOpenChat = { activeChat = it; page = AppPage.CHAT },
                    onSignOut = {
                        auth?.signOut()
                        activeUid = null
                        profile = null
                        activeChat = null
                        page = AppPage.PHONE
                        notice = ""
                    }
                )
            }
        }

        AppPage.CHAT -> {
            val uid = activeUid
            val chat = activeChat
            val store = db
            if (uid == null || chat == null || store == null) {
                page = AppPage.HOME
            } else {
                DdcConversation(
                    db = store,
                    chat = chat,
                    currentUid = uid,
                    onBack = { page = AppPage.HOME }
                )
            }
        }
    }
}

private fun normalizePhone(input: String): String {
    val value = input.trim().replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
    return when {
        value.startsWith("+") -> value
        value.startsWith("00") -> "+" + value.drop(2)
        value.startsWith("0") -> "+20" + value.drop(1)
        else -> "+" + value
    }
}

private fun chatFromSnapshot(id: String, data: Map<String, Any>): DdcChat {
    val members = (data["members"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val rawNames = data["memberNames"] as? Map<*, *>
    val names = rawNames?.entries?.mapNotNull { (key, value) ->
        if (key is String && value is String) key to value else null
    }?.toMap().orEmpty()
    return DdcChat(id, members, names, data["lastMessage"] as? String ?: "")
}

@Composable
private fun DdcLogo() {
    Box(
        modifier = Modifier.size(64.dp).background(DdcGreen.copy(alpha = 0.14f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Default.ChatBubble, contentDescription = null, tint = DdcGreen, modifier = Modifier.size(34.dp))
    }
}

@Composable
private fun BrandHeader(subtitle: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        DdcLogo()
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DDC", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
            Spacer(Modifier.width(7.dp))
            Text("Chat", fontSize = 30.sp, fontWeight = FontWeight.Black, color = DdcGreen)
        }
        Text(subtitle, color = DdcMuted, fontSize = 13.sp)
    }
}

@Composable
private fun PhonePage(
    phone: String,
    onPhoneChange: (String) -> Unit,
    firebaseConfigured: Boolean,
    busy: Boolean,
    notice: String,
    onSendCode: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().imePadding().padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        BrandHeader("تواصل مع الناس اللي يهموك")
        Spacer(Modifier.height(38.dp))
        Text("أهلًا بيك في DDC Chat", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("سجّل برقم هاتفك عشان تبدأ المحادثات", color = DdcMuted, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = phone,
            onValueChange = onPhoneChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("رقم الهاتف") },
            placeholder = { Text("+201012345678") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onSendCode,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = DdcGreen, contentColor = Color.Black)
        ) {
            if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black, strokeWidth = 2.dp)
            else Text("إرسال رمز التحقق", fontWeight = FontWeight.Bold)
        }
        if (!firebaseConfigured) {
            Spacer(Modifier.height(14.dp))
            Text("ملف Firebase غير مضاف بعد. اتبع خطوات الربط في ملف README.", color = Color(0xFFFFC766), fontSize = 12.sp)
        }
        if (notice.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(notice, color = Color(0xFFFF9B8F), fontSize = 13.sp)
        }
        Spacer(Modifier.height(28.dp))
        Text("DDC Chat • Connect • Chat • Share", color = DdcMuted, fontSize = 11.sp)
    }
}

@Composable
private fun OtpPage(
    otp: String,
    onOtpChange: (String) -> Unit,
    busy: Boolean,
    notice: String,
    onVerify: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().imePadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        BrandHeader("تأكيد رقم الهاتف")
        Spacer(Modifier.height(32.dp))
        Text("اكتب رمز التحقق", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = otp,
            onValueChange = { onOtpChange(it.filter(Char::isDigit).take(6)) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("رمز SMS") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(Modifier.height(14.dp))
        Button(onClick = onVerify, enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp)) {
            if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black)
            else Text("تأكيد ودخول", fontWeight = FontWeight.Bold)
        }
        TextButton(onClick = onBack) { Text("رجوع") }
        if (notice.isNotBlank()) Text(notice, color = Color(0xFFFF9B8F), fontSize = 13.sp)
    }
}

@Composable
private fun ProfilePage(
    busy: Boolean,
    notice: String,
    onSave: (String, String) -> Unit
) {
    var displayName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    Column(
        modifier = Modifier.fillMaxSize().imePadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        BrandHeader("جهّز حسابك")
        Spacer(Modifier.height(30.dp))
        OutlinedTextField(displayName, { displayName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اسمك الظاهر") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(username, { username = it.lowercase().filter { ch -> ch.isLetterOrDigit() || ch == '_' }.take(20) }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم المستخدم") }, placeholder = { Text("abdallah_01") }, prefix = { Text("@") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        Text("استخدم اسمًا من 3 إلى 20 حرفًا إنجليزيًا أو رقمًا أو _", color = DdcMuted, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        Button(onClick = { onSave(displayName, username) }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp)) {
            if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black)
            else Text("إنشاء الحساب", fontWeight = FontWeight.Bold)
        }
        if (notice.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(notice, color = Color(0xFFFF9B8F), fontSize = 13.sp)
        }
    }
}

@Composable
private fun DdcHome(
    db: FirebaseFirestore,
    uid: String,
    profile: DdcProfile,
    notice: String,
    busy: Boolean,
    onStartChat: (String) -> Unit,
    onOpenChat: (DdcChat) -> Unit,
    onSignOut: () -> Unit
) {
    val chats = remember { mutableStateListOf<DdcChat>() }
    var showNewChat by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }

    DisposableEffect(uid) {
        val registration = db.collection("chats")
            .whereArrayContains("members", uid)
            .orderBy("updatedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error == null && snapshot != null) {
                    val updated = snapshot.documents.map { chatFromSnapshot(it.id, it.data.orEmpty()) }
                    chats.clear()
                    chats.addAll(updated)
                }
            }
        onDispose { registration.remove() }
    }

    Column(modifier = Modifier.fillMaxSize().background(DdcBackground)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DdcLogo()
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("DDC", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Spacer(Modifier.width(5.dp))
                    Text("Chat", fontSize = 25.sp, fontWeight = FontWeight.Black, color = DdcGreen)
                }
                Text("مرحبًا ${profile.displayName}", color = DdcMuted, fontSize = 12.sp)
            }
            IconButton(onClick = onSignOut) {
                Icon(Icons.Default.Logout, contentDescription = "تسجيل الخروج", tint = DdcMuted)
            }
        }
        Text("المحادثات", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        if (notice.isNotBlank()) Text(notice, color = Color(0xFFFFB4A9), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp))
        if (chats.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ChatBubble, contentDescription = null, tint = DdcGreen, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("لسه مفيش محادثات", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("ابدأ محادثة جديدة باستخدام اسم المستخدم", color = DdcMuted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(chats, key = { it.id }) { chat ->
                    val otherUid = chat.otherUid(uid)
                    val display = chat.memberNames[otherUid].orEmpty().ifBlank { "مستخدم DDC" }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp)
                            .background(DdcSurface, RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(46.dp).background(DdcGreen.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
                            Text(display.take(1), color = DdcGreen, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(display, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(chat.lastMessage.ifBlank { "ابدأ المحادثة الآن" }, color = DdcMuted, fontSize = 12.sp, maxLines = 1)
                        }
                        TextButton(onClick = { onOpenChat(chat) }) { Text("فتح", color = DdcGreen) }
                    }
                }
            }
        }
        Button(
            onClick = { showNewChat = true },
            modifier = Modifier.fillMaxWidth().padding(18.dp).height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DdcGreen, contentColor = Color.Black)
        ) {
            Icon(Icons.Default.PersonAdd, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("محادثة جديدة", fontWeight = FontWeight.Bold)
        }
    }

    if (showNewChat) {
        AlertDialog(
            onDismissRequest = { showNewChat = false },
            title = { Text("ابدأ محادثة") },
            text = {
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' }.take(20) },
                    label = { Text("اسم المستخدم") },
                    placeholder = { Text("abdallah_01") },
                    prefix = { Text("@") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = { showNewChat = false; onStartChat(username) }, enabled = !busy) { Text("ابدأ", color = DdcGreen) }
            },
            dismissButton = { TextButton(onClick = { showNewChat = false }) { Text("إلغاء") } },
            containerColor = DdcSurface,
            titleContentColor = Color.White,
            textContentColor = DdcMuted
        )
    }
}

@Composable
private fun DdcConversation(
    db: FirebaseFirestore,
    chat: DdcChat,
    currentUid: String,
    onBack: () -> Unit
) {
    val messages = remember(chat.id) { mutableStateListOf<DdcMessage>() }
    var draft by remember(chat.id) { mutableStateOf("") }
    var errorText by remember(chat.id) { mutableStateOf("") }
    val listState = rememberLazyListState()
    val otherUid = chat.otherUid(currentUid)
    val otherName = chat.memberNames[otherUid].orEmpty().ifBlank { "محادثة DDC" }

    DisposableEffect(chat.id) {
        val registration = db.collection("chats").document(chat.id)
            .collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    errorText = error.localizedMessage ?: "تعذر تحميل الرسائل"
                } else if (snapshot != null) {
                    val updated = snapshot.documents.map { doc ->
                        DdcMessage(
                            id = doc.id,
                            senderId = doc.getString("senderId").orEmpty(),
                            text = doc.getString("text").orEmpty(),
                            createdAt = doc.getTimestamp("createdAt")
                        )
                    }
                    messages.clear()
                    messages.addAll(updated)
                }
            }
        onDispose { registration.remove() }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    Column(modifier = Modifier.fillMaxSize().background(DdcBackground).imePadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().background(DdcSurface).padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color.White) }
            Box(modifier = Modifier.size(38.dp).background(DdcGreen.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
                Text(otherName.take(1), color = DdcGreen, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(otherName, color = Color.White, fontWeight = FontWeight.Bold)
                Text("DDC Chat", color = DdcMuted, fontSize = 11.sp)
            }
        }

        if (messages.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("ابدأ أول رسالة 👋", color = DdcMuted)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    val mine = message.senderId == currentUid
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End) {
                        Column(
                            modifier = Modifier.background(if (mine) DdcSent else DdcReceived, RoundedCornerShape(16.dp))
                                .padding(horizontal = 13.dp, vertical = 9.dp)
                                .fillMaxWidth(0.82f)
                        ) {
                            Text(message.text, color = Color.White, fontSize = 15.sp)
                            message.createdAt?.let {
                                Text(
                                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(it.toDate()),
                                    color = DdcMuted,
                                    fontSize = 10.sp,
                                    modifier = Modifier.align(Alignment.End)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (errorText.isNotBlank()) Text(errorText, color = Color(0xFFFF9B8F), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 14.dp))
        Row(
            modifier = Modifier.fillMaxWidth().background(DdcSurface).padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it.take(4000) },
                modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب رسالة...") },
                maxLines = 4
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = {
                    val text = draft.trim()
                    if (text.isNotEmpty()) {
                        val chatRef = db.collection("chats").document(chat.id)
                        val batch = db.batch()
                        val messageRef = chatRef.collection("messages").document()
                        batch.set(messageRef, mapOf(
                            "senderId" to currentUid,
                            "text" to text,
                            "createdAt" to FieldValue.serverTimestamp()
                        ))
                        batch.update(chatRef, mapOf(
                            "lastMessage" to text,
                            "updatedAt" to FieldValue.serverTimestamp()
                        ))
                        draft = ""
                        batch.commit().addOnFailureListener { failure ->
                            errorText = failure.localizedMessage ?: "تعذر إرسال الرسالة"
                        }
                    }
                },
                modifier = Modifier.size(48.dp).background(DdcGreen, CircleShape)
            ) {
                Icon(Icons.Default.Send, contentDescription = "إرسال", tint = Color.Black)
            }
        }
    }
}

# DDC Chat — Android starter project

مشروع Android أصلي باسم **DDC Chat** وبمعرّف الحزمة `com.ddc.chat`.

## الموجود في هذه النسخة

- تسجيل الدخول والتحقق من رقم الهاتف باستخدام Firebase Authentication.
- إنشاء ملف شخصي باسم ظاهر واسم مستخدم فريد.
- البحث عن مستخدم بواسطة اسم المستخدم وفتح محادثة فردية.
- إرسال واستقبال رسائل نصية مباشرة من خلال Cloud Firestore.
- قواعد أمان مبدئية لملفات المستخدمين والمحادثات والرسائل.
- سير عمل GitHub Actions لبناء APK تجريبي تلقائيًا.

هذه نسخة البداية الفعلية للمراسلة النصية. الصور والفيديو والرسائل الصوتية والحالات والمجموعات والمكالمات والتشفير من طرف إلى طرف وإشعارات الرسائل في الخلفية لم تُنفّذ بعد.

## 1) ربط Firebase (مطلوب لتسجيل الدخول والمراسلة الحقيقية)

1. افتح [Firebase Console](https://console.firebase.google.com/) وأنشئ مشروعًا باسم `DDC Chat`.
2. أضف تطبيق Android داخل المشروع، واكتب اسم الحزمة بالضبط: `com.ddc.chat`.
3. نزّل ملف `google-services.json` وضعه داخل مجلد `app/` بجانب `app/build.gradle.kts`.
4. من Firebase Authentication افتح Sign-in method وفعّل **Phone**.
5. من إعدادات تطبيق Android في Firebase أضف SHA-256 (وSHA-1 عند طلبه) من شهادة توقيع نسخة الاختبار. عند استخدام أرقام تجريبية، أضف رقمًا ورمزًا ثابتًا من إعدادات Phone authentication.
6. أنشئ قاعدة بيانات Cloud Firestore.
7. افتح تبويب Rules في Firestore، والصق محتوى ملف `firestore.rules` ثم اضغط Publish.
8. أنشئ الفهرس الموجود في `firestore.indexes.json` من Firestore Indexes إذا طلبت قاعدة البيانات ذلك. قد يظهر رابط إنشاء الفهرس في سجل التشغيل.

مهم: لا تضع مفاتيح Service Account أو ملفات مفاتيح الخادم الخاصة داخل تطبيق Android أو مستودع GitHub. ملف `google-services.json` هو إعداد تعريف التطبيق من Firebase، وليس بديلًا عن قواعد الأمان.

## 2) بناء APK باستخدام GitHub من الهاتف

1. فك ضغط ملف المشروع على هاتفك.
2. أنشئ مستودعًا جديدًا في GitHub باسم `ddc-chat`.
3. ارفع **محتويات المجلد** إلى جذر المستودع، بحيث يكون ملف `settings.gradle.kts` ظاهرًا في الصفحة الرئيسية للمستودع، ويكون مسار سير العمل `.github/workflows/android.yml` موجودًا كما هو.
4. افتح تبويب **Actions** في المستودع. سيبدأ البناء بعد رفع الملفات، أو اختر `Build DDC Chat APK` ثم `Run workflow`.
5. عندما تنتهي المهمة بنجاح، افتح نتيجة التشغيل وانزل إلى **Artifacts** ثم نزّل `DDC-Chat-debug-APK`.
6. فك ضغط ملف Artifact وثبّت `app-debug.apk` على هاتف Android. قد تحتاج إلى السماح بالتثبيت من هذا المصدر.

يستطيع GitHub بناء APK حتى قبل وضع إعداد Firebase، لكن شاشة تسجيل الدخول ستطلب إضافة `google-services.json`. لن يعمل إرسال رمز SMS أو تبادل الرسائل حتى تنفذ خطوات Firebase بالأعلى وتعيد البناء.

## 3) متطلبات البناء

- JDK 17
- Gradle 8.13
- Android SDK Platform 36
- Android Gradle Plugin 8.13.2

GitHub Actions يجهز هذه المتطلبات تلقائيًا.

## 4) هيكل البيانات المختصر

- `profiles/{uid}`: الاسم الظاهر واسم المستخدم.
- `usernames/{username}`: ربط اسم المستخدم بمعرّف الحساب.
- `chats/{chatId}`: عضوية المحادثة وآخر رسالة.
- `chats/{chatId}/messages/{messageId}`: الرسائل النصية.

رقم الهاتف تتم إدارته بواسطة Firebase Authentication ولا نخزنه في مستند الملف الشخصي العام.
